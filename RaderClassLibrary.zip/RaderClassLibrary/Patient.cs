﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderClassLibrary
{
    public class Patient : ApplicationUser
    {
        public string Address{ get; set; }
        public DateTime DOB { get; set; }
        public int? PriorityLevel { get; set; }

        public Patient(string firstName, string lastName, string email, string phone, string password, string address, DateTime dob, int? priorityLevel = null):base(firstName, lastName, email, phone, password)
        {     
            this.Address = address;
            this.DOB = dob;

            if(priorityLevel != null)
            {
                this.PriorityLevel = priorityLevel;
            }
            

        }

        public Patient()
        {

        }

    }
}
