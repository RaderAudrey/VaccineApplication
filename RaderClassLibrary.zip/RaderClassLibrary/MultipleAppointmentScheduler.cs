﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaderClassLibrary
{
    public class MultipleAppointmentScheduler
    {
        [Key]
        public int MultipleAppointmentSchedulerID { get; set; }
        public DateTime SchedulerDateTime { get; set; }

        public string PatientID { get; set; }

        [ForeignKey("PatientID")]
        public Patient Patient { get; set; }

        public MultipleAppointmentScheduler(string patientID)
        {
            this.PatientID = patientID;
            this.SchedulerDateTime = DateTime.Now;
        }

        public MultipleAppointmentScheduler() { }

    }//end class MultipleAppointmentScheduler
}
