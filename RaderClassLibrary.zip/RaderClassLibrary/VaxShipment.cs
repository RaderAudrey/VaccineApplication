﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaderClassLibrary
{
    public class VaxShipment
    {
        [Key]
        public int VaccineShipmentID { get; set; } //autognerated

        [Required(ErrorMessage ="Start Date is Required")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; } //needed

        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }//needed

        public int NumberofVaxShip { get; set; } //needed

        public int NumberofVaxUsed { get; set; } //needed

        //realtion DB connections

        public int FacilityID { get; set; }

        public int VaccineID { get; set; }

        //object-oriented connections

        public Facility Facility { get; set; }

        public Vaccine Vaccine { get; set; }



        [ForeignKey("FacilityAdminID")]
        public FacilityAdmin FacilityAdmin { get; set; }
     
        public string FacilityAdminID { get; set; }
      

        public VaxShipment(int facilityID, int vaccineID, DateTime startDate, int numberofVaxShip, DateTime? endDate = null)
        {
            this.FacilityID = facilityID;
            this.VaccineID = vaccineID;
            this.StartDate = startDate;
            
            if (endDate != null)
            {
                this.EndDate = (DateTime)endDate;
            }
            else
            {
                this.EndDate = startDate.AddDays(7);
            }

            this.NumberofVaxShip = numberofVaxShip;
            this.NumberofVaxUsed = 0;
         
        }


        public VaxShipment()
        {

        } 

        //branched
    }
}
