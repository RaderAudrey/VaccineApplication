﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RaderClassLibrary
{
    public class Vaccine
    {
        [Key]
        public int VaccineID { get; set; }
        public int IntervalBetweenShots { get; set; }
        public string Name { get; set; }
        public int NumbOfShots { get; set; }
        public List<VaxShipment> VaccineShipments { get; set; }
        public List<VaccineExchange> VaccineExchanges { get; set; }


        public Vaccine(string name, int intervalBetweenShots, int numberOfShots)
        {
            this.Name = name;
            this.NumbOfShots = numberOfShots;
            this.IntervalBetweenShots = intervalBetweenShots;
            this.VaccineShipments = new List<VaxShipment>();
            this.VaccineExchanges = new List<VaccineExchange>();
        }
        
        
        public Vaccine()
        {
            this.VaccineShipments = new List<VaxShipment>();
            this.VaccineExchanges = new List<VaccineExchange>();
        }
    

    }

}

    



    
