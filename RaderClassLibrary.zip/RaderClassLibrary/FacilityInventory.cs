﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace RaderClassLibrary
{
    public class FacilityInventory
    {

        [Key]
        public int FacilityInventoryID { get; set; }
        public int CurrentInventory { get; set; }
        public int FacilityID { get; set; }
        public int VaccineID { get; set; }

        //FacilityInventoryID, CurrentInventory, FacilityID, VaccineID

        [ForeignKey("FacilityID")]
        public Facility Facility { get; set; }



        [ForeignKey("VaccineID")]
        public Vaccine Vaccine { get; set; }


        public FacilityInventory(int facilityID, int vaccineID)
        {
            this.FacilityID = facilityID;
            this.VaccineID = vaccineID;
            this.CurrentInventory = 0;
        }

        public FacilityInventory()
        {

        }
    }
}