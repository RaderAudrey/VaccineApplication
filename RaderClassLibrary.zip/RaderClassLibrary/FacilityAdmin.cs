﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderClassLibrary
{
    public class FacilityAdmin : ApplicationUser
    {
        public int FacilityID { get; set; }

        public Facility Facility { get; set; }

        public FacilityAdmin(string firstName, string lastName, string email, string phone, string password) : base(firstName, lastName, email, phone, password)
        {
            //this.FacilityID = facilityID;
        }

        public FacilityAdmin()
        { }


    }//end class






}//end namespace
