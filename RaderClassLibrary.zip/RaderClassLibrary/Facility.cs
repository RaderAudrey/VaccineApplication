﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace RaderClassLibrary
{
    public class Facility
    {
        // every MVC class will have a property for a primary key (ID)
        //instance variavles (attribute) v property
        // facilityID v FacilityID
        
        
        [Key]
        public int FacilityID { get; set; }
        public string FacilityName { get; set; }
        public string FacilityAddress { get; set; }

        public string FacilityAdminID { get; set; }

        public List<VaxShipment> VaccineShipmentsToFacility { get; set; }

        [NotMapped]
        public List<VaccineExchange> SendingVaccineExchange { get; set; }
        [NotMapped]
        public List<VaccineExchange> RecievingVaccineExchange { get; set; }


        [ForeignKey("FacilityAdminID")]
        public FacilityAdmin FacilityAdmin { get; set; }

        //constructoir is  a method (signature)
        //public return type methodname (out perametername....)

        public Facility(string facilityName, string facilityAddress)
        {
            this.FacilityName = facilityName;
            this.FacilityAddress = facilityAddress;
            this.VaccineShipmentsToFacility = new List<VaxShipment>();
        }

        public Facility()
        {

        }

    }


}
