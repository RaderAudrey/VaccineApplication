﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaderClassLibrary
{
    public class AppointmentAvailabilityAlternate
    {
        [Key]
        public int AppointmentAvailabilityAlternateID { get; set; }

        public int? MultipleAppointmentSchedulerID { get; set; }

        [ForeignKey("MultipleAppointmentSchedulerID")]
        public MultipleAppointmentScheduler MultipleAppointmentScheduler { get; set; }

        public DateTime AppointmentDateStartTime { get; set; }

        public DateTime AppointmentEndTime { get; set; }

        public AppointmentStatusOptions AppointmentStatus { get; set; }

        public AppointmentAvailabilityAlternate(DateTime appointmentDateStartTime)
        {
            this.AppointmentDateStartTime = appointmentDateStartTime;
            this.AppointmentEndTime = appointmentDateStartTime.AddMinutes(15);
            this.AppointmentStatus = AppointmentStatusOptions.Open;
        }

        public AppointmentAvailabilityAlternate() { }

    }//end class AppointmentAvailabilityAlternate
}
