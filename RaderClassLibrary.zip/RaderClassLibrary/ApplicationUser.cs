﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderClassLibrary
{
    //inheritance
    public class ApplicationUser : IdentityUser
    {
        //built in ID
        public string FirstName{ get; set; }
        public string LastName { get; set; }
        public string FullName
        {
            get { return (FirstName + ' ' + LastName); }
        }


        public ApplicationUser(string firstName, string lastName, string email, string phone, string password)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Email = email;
            this.UserName = email;
            this.PhoneNumber = phone;

            PasswordHasher<ApplicationUser> passwordHasher = new PasswordHasher<ApplicationUser>();
            this.PasswordHash = passwordHasher.HashPassword(this, password);

            this.SecurityStamp = Guid.NewGuid().ToString();
        }

        //required for entitiy framework (aka object relational mapper : ORM, takes classes and maps them to tables in databases)
        public ApplicationUser(){}


    }
}
