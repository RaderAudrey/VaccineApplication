﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using RaderMVCWebProject.Controllers;
using RaderMVCWebProject.Models;
using RaderClassLibrary;
using RaderMVCWebProject.View_Models;
using System;
using System.Collections.Generic;
using Xunit;

namespace RaderTestProject
{
    public class VaccineExchangeTest
    {
        private readonly Mock<IVaccineExchangeRepo> mockVaccineExchangeRepo;
        private readonly Mock<IFacilityRepo> mockfacilityrepo;
        private readonly Mock<IApplicationUserRepo> mockApplicationUserRepo;
        private readonly Mock<IFacilityInventoryRepo> mockFacilityInventoryRepo;
        private readonly VaccineExchangeController controller;


        public VaccineExchangeTest()
        {            
            mockVaccineExchangeRepo = new Mock<IVaccineExchangeRepo>();
            mockfacilityrepo = new Mock<IFacilityRepo>();
            mockApplicationUserRepo = new Mock<IApplicationUserRepo>();
            mockFacilityInventoryRepo = new Mock<IFacilityInventoryRepo>();

            controller = new VaccineExchangeController(mockVaccineExchangeRepo.Object, mockfacilityrepo.Object, mockApplicationUserRepo.Object, mockFacilityInventoryRepo.Object);
        }

        [Fact]
        public void ShouldMakeVaccineExchange()
        {
            //arrange
            AddVaccineExchangeViewModel viewModel = new AddVaccineExchangeViewModel
            {
                ExchangedDoses = 999,
                SendingFacilityID = 1,
                RecievingFacilityID = 11,
                VaccineID = 2
            };

            DateTime expectedDate = DateTime.Today.Date;

            VaccineExchange vaxExchange = new VaccineExchange();
            int mockVaxExchangeID = 1234;

            FacilityInventory sendingfacilityinventory = new FacilityInventory(viewModel.SendingFacilityID, viewModel.VaccineID);
            FacilityInventory recievingfacilityinventory = new FacilityInventory(viewModel.RecievingFacilityID, viewModel.VaccineID);

            sendingfacilityinventory.CurrentInventory = 1000;


            mockVaccineExchangeRepo
                .Setup(m => m.MakeVaccineExchange(It.IsAny<VaccineExchange>()))
                .Returns(mockVaxExchangeID);

            mockVaccineExchangeRepo
               .Setup(m => m.MakeVaccineExchange(It.IsAny<VaccineExchange>()))
               .Returns(mockVaxExchangeID)
               .Callback<VaccineExchange>(m => vaxExchange = m);

            mockFacilityInventoryRepo.Setup(m => m.FindFacilityInventory(sendingfacilityinventory.FacilityID, sendingfacilityinventory.VaccineID))
                .Returns(sendingfacilityinventory);

            mockFacilityInventoryRepo.Setup(m => m.FindFacilityInventory(recievingfacilityinventory.FacilityID, recievingfacilityinventory.VaccineID))
            .Returns(recievingfacilityinventory);

            //act
            controller.MakeVaccineExchange(viewModel);

            //assert
            mockVaccineExchangeRepo.Verify(m => m.MakeVaccineExchange(It.IsAny<VaccineExchange>()), Times.Exactly(1));
            Assert.Equal(mockVaxExchangeID, vaxExchange.VaccineExchangeID);
            Assert.Equal(expectedDate, vaxExchange.ExchangedDate);
        }

        //sad path
        [Fact]
        public void ShouldnotmakeVaccineExchange()
        {
            //arrange
            mockfacilityrepo.Setup(f => f.ListofAllFacilities()).Returns(new List<Facility>());

            AddVaccineExchangeViewModel viewModel = new AddVaccineExchangeViewModel
            {
                ExchangedDoses = 999,
                SendingFacilityID = 1,
                RecievingFacilityID = 2,
                VaccineID = 2
            };

            DateTime expectedDate = DateTime.Today.Date;

            FacilityInventory sendingfacilityinventory = new FacilityInventory(viewModel.SendingFacilityID, viewModel.VaccineID);

            sendingfacilityinventory.CurrentInventory = 998;

            mockFacilityInventoryRepo.Setup(m => m.FindFacilityInventory(viewModel.SendingFacilityID, viewModel.VaccineID)).Returns(sendingfacilityinventory);                      

            //act
            controller.MakeVaccineExchange(viewModel);

            //assert
            mockVaccineExchangeRepo.Verify(m => m.MakeVaccineExchange(It.IsAny<VaccineExchange>()), Times.Never);

            int expectedcurrentinventoryforsending = 998;

            Assert.Equal(expectedcurrentinventoryforsending, sendingfacilityinventory.CurrentInventory);
            //sadpath
        }



    }
}
