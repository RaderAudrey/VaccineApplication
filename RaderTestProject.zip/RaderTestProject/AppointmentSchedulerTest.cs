﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using RaderMVCWebProject.Controllers;
using RaderMVCWebProject.Models;
using RaderClassLibrary;
using RaderMVCWebProject.View_Models;
using System;
using System.Collections.Generic;
using Xunit;

namespace RaderTestProject
{
    public class AppointmentSchedulerTest
    {
        private readonly Mock<IVaccineExchangeRepo> mockVaccineExchangeRepo;
        private readonly Mock<IFacilityRepo> mockfacilityrepo;
        private readonly Mock<IApplicationUserRepo> mockApplicationUserRepo;
        private readonly Mock<IFacilityInventoryRepo> mockFacilityInventoryRepo;
        private readonly Mock<IAppointmentAvailabilityRepo> mockappoitnemtnavailabilityRepo;

        private readonly AppointmentSchedulerController controller;


        public AppointmentSchedulerTest()
        {
            mockVaccineExchangeRepo = new Mock<IVaccineExchangeRepo>();
            mockfacilityrepo = new Mock<IFacilityRepo>();
            mockApplicationUserRepo = new Mock<IApplicationUserRepo>();
            mockFacilityInventoryRepo = new Mock<IFacilityInventoryRepo>();
            mockappoitnemtnavailabilityRepo = new Mock<IAppointmentAvailabilityRepo>();

            controller = new AppointmentSchedulerController(mockVaccineExchangeRepo.Object, mockfacilityrepo.Object, mockApplicationUserRepo.Object, mockFacilityInventoryRepo.Object, mockappoitnemtnavailabilityRepo.Object);
        }

        [Fact]
        public void ShouldSceduleAppointment()
        {
            //1. Arrange
            int appointmentAvailabilityID = 999;
            string expectedPatientID = "TESTtest";

            AppointmentAvailability testappointmentAvailability = new AppointmentAvailability
            {
                AppoinmentAvailabilityID = 999,
                AppointmentStartTime = new DateTime(2021, 9, 19),                
                FacilityInventoryID = 1
            };
            FacilityInventory facilityInventory = new FacilityInventory
            {
                //FacilityInventoryID, CurrentInventory, FacilityID, VaccineID
                FacilityInventoryID = 1,
                CurrentInventory = 1000,
                FacilityID = 1,
                VaccineID = 101
            };

            mockappoitnemtnavailabilityRepo
                .Setup(m => m.FindAppointmentAvailability(appointmentAvailabilityID))
                .Returns(testappointmentAvailability);

            mockApplicationUserRepo
                .Setup(m => m.FindUserID())
                .Returns(expectedPatientID);

            mockFacilityInventoryRepo
                .Setup(m => m.FindFacilityInventory(testappointmentAvailability.FacilityInventoryID))
                .Returns(facilityInventory);

            mockappoitnemtnavailabilityRepo
                .Setup(m => m.ScheduleAppointment(testappointmentAvailability))
                .Callback<AppointmentAvailability>(m => testappointmentAvailability = m);

            mockFacilityInventoryRepo
                .Setup(m => m.UpdateCurrentInventory(facilityInventory))
                .Callback<FacilityInventory>(m => facilityInventory = m);

            //2. Act
            controller.ScheduleAppoinment(testappointmentAvailability.AppoinmentAvailabilityID);


            int expectedcurrentInventory = 999;

            //3. Assert
            mockappoitnemtnavailabilityRepo.Verify(m => m.ScheduleAppointment(It.IsAny<AppointmentAvailability>()), Times.Exactly(1));
            mockFacilityInventoryRepo.Verify(m => m.UpdateCurrentInventory(It.IsAny<FacilityInventory>()), Times.Exactly(1));


            Assert.Equal(expectedPatientID, testappointmentAvailability.PatientID);
            Assert.Equal(expectedcurrentInventory, facilityInventory.CurrentInventory);
            Assert.Equal(AppointmentStatusOptions.Booked, testappointmentAvailability.AppointmentStatus);
        }


        //sad path 
        [Fact(Skip ="not done")]
        public void ShouldNotSceduleAppointment()
        {
            //1. Arrange
            //mockfacilityrepo.Setup(f => f.ListofAllFacilities()).Returns(new List<Facility>());

            int appointmentAvailabilityID = 999;
            int currentinventory = 0;
            string expectedPatientID = null;

            AppointmentAvailability testappointmentAvailability = new AppointmentAvailability();
            FacilityInventory facilityInventory = new FacilityInventory();

            mockappoitnemtnavailabilityRepo
                .Setup(m => m.FindAppointmentAvailability(appointmentAvailabilityID))
                .Returns(testappointmentAvailability);           

            //2. Act
            controller.ScheduleAppoinment(appointmentAvailabilityID);


            int expectedcurrentInventory = 0;

            //3. Assert
            mockappoitnemtnavailabilityRepo.Verify(m => m.ScheduleAppointment(It.IsAny<AppointmentAvailability>()), Times.Never);

            Assert.Equal(expectedPatientID, testappointmentAvailability.PatientID);
            Assert.Equal(expectedcurrentInventory, facilityInventory.CurrentInventory);
        }

        [Fact]
        public void ShouldCancelAppointment()
        {
            //Arrange
            AppointmentAvailability appointmentavailavbility = new AppointmentAvailability
            {
                AppoinmentAvailabilityID = 999,
                AppointmentStatus = AppointmentStatusOptions.Booked,
                AppointmentStartTime = new DateTime(2021, 9, 19),
                AppointmentBooked = new DateTime(2021, 8, 20),
                FacilityInventoryID = 1,
                PatientID = "IAMDYING"        
            };
            AppointmentAvailability newappointmentavailavbility = new AppointmentAvailability
            {
                AppoinmentAvailabilityID = 999,
                AppointmentStartTime = new DateTime(2021, 9, 19),
                AppointmentStatus = AppointmentStatusOptions.Open,
                FacilityInventoryID = 1,
            };

      
            FacilityInventory facilityInventory = new FacilityInventory
            {
                //FacilityInventoryID, CurrentInventory, FacilityID, VaccineID
                FacilityInventoryID = 1,
                CurrentInventory = 999,
                FacilityID = 1,
                VaccineID = 101
            };

            //iappoitnemtnavailabilityRepo.FindAppointmentAvailability
            mockappoitnemtnavailabilityRepo
               .Setup(m => m.FindAppointmentAvailability(appointmentavailavbility.AppoinmentAvailabilityID))
               .Returns(appointmentavailavbility);

            //ifacilityInventoryRepo.FindFacilityInventory
            mockFacilityInventoryRepo
               .Setup(m => m.FindFacilityInventory(appointmentavailavbility.FacilityInventoryID))
               .Returns(facilityInventory);

            //ifacilityInventoryRepo.UpdateCurrentInventory
            mockFacilityInventoryRepo
                 .Setup(m => m.UpdateCurrentInventory(facilityInventory))
                 .Callback<FacilityInventory>(m => facilityInventory = m);

            //iappoitnemtnavailabilityRepo.EditAppointment
            mockappoitnemtnavailabilityRepo
              .Setup(m => m.EditAppointment(appointmentavailavbility))
              .Callback<AppointmentAvailability>(m => appointmentavailavbility = m);

            //iappoitnemtnavailabilityRepo.AddAppointmentAvailability        
            mockappoitnemtnavailabilityRepo
              .Setup(m => m.AddAppointmentAvailability(newappointmentavailavbility))
              .Callback<AppointmentAvailability>(m => newappointmentavailavbility = m);


            //2. Act
            controller.PatientCancelAppointment(appointmentavailavbility);

            int expectedcurrentInventory = 1000;
            string expectedPatientID = null;

            //3. Assert
            mockappoitnemtnavailabilityRepo.Verify(m => m.EditAppointment(It.IsAny<AppointmentAvailability>()), Times.Exactly(1));
            mockFacilityInventoryRepo.Verify(m => m.UpdateCurrentInventory(It.IsAny<FacilityInventory>()), Times.Exactly(1));


            Assert.Equal(expectedcurrentInventory, facilityInventory.CurrentInventory);
            Assert.Equal(AppointmentStatusOptions.Cancelled, appointmentavailavbility.AppointmentStatus);
            Assert.Equal(AppointmentStatusOptions.Open, newappointmentavailavbility.AppointmentStatus);
            Assert.Equal(expectedPatientID, newappointmentavailavbility.PatientID);
        }

    }
}
