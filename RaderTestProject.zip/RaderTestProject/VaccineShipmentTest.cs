using Microsoft.AspNetCore.Mvc;
using Moq;
using RaderMVCWebProject.Controllers;
using RaderMVCWebProject.Models;
using RaderClassLibrary;
using RaderMVCWebProject.View_Models;
using System;
using System.Collections.Generic;
using Xunit;

namespace RaderTestProject
{
    public class VaccineShipmentTest
    {
        private readonly Mock<IVaccineShipmentRepo> mockVaccineShipmentRepo;
        private readonly Mock<IFacilityRepo> mockfacilityrepo;
        private readonly Mock<IApplicationUserRepo> mockApplicationUserRepo;
        private readonly Mock<IFacilityInventoryRepo> mockFacilityInventoryRepo;

        private readonly VaccineShipmentController controller;


        public VaccineShipmentTest()
        {
            mockfacilityrepo = new Mock<IFacilityRepo>();
            mockVaccineShipmentRepo = new Mock<IVaccineShipmentRepo>();
            mockApplicationUserRepo = new Mock<IApplicationUserRepo>();
            mockFacilityInventoryRepo = new Mock<IFacilityInventoryRepo>();
            controller = new VaccineShipmentController(mockVaccineShipmentRepo.Object, mockfacilityrepo.Object, mockApplicationUserRepo.Object, mockFacilityInventoryRepo.Object);
        }

        //editing
        [Fact]
        public void ShouldFindVaccineShipment()
        {
            //1. Arrange
            int vaxshipID = 9999;
            VaxShipment expectedVaxShip = new VaxShipment(11, 22, new DateTime(2021, 1, 1), 33);

            mockVaccineShipmentRepo.Setup(m => m.FindVaccineShipment(vaxshipID))
                .Returns(expectedVaxShip);

            mockfacilityrepo.Setup(m => m.ListofAllFacilities()).Returns(new List<Facility>());

            //2. Act
            ViewResult viewresult = controller.EditVaccineShipment(vaxshipID) as ViewResult;
            VaxShipment actualVaxship = viewresult.Model as VaxShipment;


            //3. Assert
            Assert.Equal(expectedVaxShip, actualVaxship);


        }

        [Fact]
        public void ShouldEditVaccineShipment()
        {
            //1. Arrange
            int vaxshipID = 9999;
            VaxShipment originalVaxShip = new VaxShipment(11, 22, new DateTime(2021, 1, 1), 33);
            VaxShipment modifiedVaxShip = new VaxShipment(110, 220, new DateTime(2021, 1, 1), 330);

            mockVaccineShipmentRepo
                 .Setup(m => m.EditVaccineShipment(modifiedVaxShip))
                 .Callback<VaxShipment>(vs => originalVaxShip = vs);           
           
            //  mockfacilityrepo.Setup(m => m.ListofAllFacilities()).Returns(new List<Facility>());

            //2. Act

            controller.EditVaccineShipment(modifiedVaxShip);

            //3. Assert
            Assert.Equal(originalVaxShip, modifiedVaxShip);

        }



        
        //happy path: everything goes as it should, aka user provided all inputs
        [Fact]
        public void ShouldAddVaxShipment()
        {
            // 1. Arrange
            string facilityAdminID = "M12345";
            mockApplicationUserRepo.Setup(m => m.FindUserID())
                .Returns(facilityAdminID);

            AddVaxShipmentViewModel viewModel = new AddVaxShipmentViewModel
            {
                FacilityID = 1,
                VaccineID = 2,
                StartDate = new DateTime(2021, 9, 19),
                EndDate = null, //new DateTime(2021, 9, 26),  expected end date //next time will test with null value
                NumberofVaxShip = 9999
            };

            FacilityInventory facilityinventory = new FacilityInventory(viewModel.FacilityID, viewModel.VaccineID);
            facilityinventory.CurrentInventory = 0;

            VaxShipment vaxShipmenttest = 
                new VaxShipment();
           int mockVaxShipmentID = 9999;
           int expectedupdatedfacilityinventory = 9999;

            DateTime expectedEndDate = new DateTime(2021, 9, 26);

            mockVaccineShipmentRepo
                .Setup(m => m.AddVaccineShipment(It.IsAny<VaxShipment>()))
                .Returns(mockVaxShipmentID);

            mockVaccineShipmentRepo
                .Setup(m => m.AddVaccineShipment(It.IsAny<VaxShipment>()))
                .Returns(mockVaxShipmentID)
                .Callback<VaxShipment>(vs => vaxShipmenttest = vs);

            mockFacilityInventoryRepo
                .Setup(m => m.FindFacilityInventory(facilityinventory.FacilityID, facilityinventory.VaccineID))
           .Returns(facilityinventory);
          
            mockFacilityInventoryRepo
               .Setup(m => m.UpdateCurrentInventory(facilityinventory))
               .Callback<FacilityInventory>(m => facilityinventory = m);


            // 2. Act
            controller.AddVaccineShipment(viewModel);


            // 3. Assert
            mockVaccineShipmentRepo.Verify(m => m.AddVaccineShipment(It.IsAny<VaxShipment>()), Times.Exactly(1));
            Assert.Equal(mockVaxShipmentID, vaxShipmenttest.VaccineShipmentID);
            Assert.Equal(expectedEndDate, vaxShipmenttest.EndDate);
            Assert.Equal(facilityAdminID, vaxShipmenttest.FacilityAdminID);
            Assert.Equal(expectedupdatedfacilityinventory, facilityinventory.CurrentInventory);
        }



        //sad path: method that shouldn't add Vax Shipment bc inputs are not all correct or inputted






        [Fact]//TDD Test Driven Development (inceremental) : red - green
        public void ShouldListAllVaccineShipments()
        {
            ///AAA testing, we expect something to happen
            ///1. Arrange           
            int expectedNumberOfShipments = 6;
            int actualNumberOfShipments = 0;
            List<VaxShipment> mockVaccineshipments = CreateMockVaccineShipmentData();
            //inject mock data into the controller method
            mockVaccineShipmentRepo.Setup(m => m.ListallVaccineShipments()).Returns(mockVaccineshipments);


            ///2. Act
            ViewResult result =  controller.ListallVaccineShipments() as ViewResult; //get back result 
            //look inside returned result object (list)
            List < VaxShipment > actualVaccineShipments = result.Model as List<VaxShipment>;
            //count the list (ActualNumberOfShipments)
            actualNumberOfShipments = actualVaccineShipments.Count;


            ///3. Assert(fails -> succeeds)
            Assert.Equal(expectedNumberOfShipments, actualNumberOfShipments);
        }

        //SearchVaccineShipments 
        //1. Date (StartDate and EndDate)
        //2. Name (Vaccine)
        //3. Facility Name / Address

    
        [Fact]
        public void SearchVaccineShipments()
        {
            ///1. Arrange           
            int expectedNumberOfShipments = 3;
            int actualNumberOfShipments = 0;
            List<VaxShipment> mockVaccineshipments = CreateMockVaccineShipmentData();
            //inject mock data into the controller method
            mockVaccineShipmentRepo.Setup(m => m.ListallVaccineShipments()).Returns(mockVaccineshipments);
            mockfacilityrepo.Setup(m => m.ListofAllFacilities()).Returns(new List<Facility>());

            DateTime startDate = new DateTime(2021, 4, 11);

            SearchVaccineShipmentsViewModel viewModel = new SearchVaccineShipmentsViewModel();

            viewModel.StartDate = startDate;
            viewModel.EndDate = null;
            viewModel.FacilityID = null;
            viewModel.VaccineID = null;

            ///2. Act
            ViewResult result =  controller.SearchVaccineShipments(viewModel) as ViewResult;

            SearchVaccineShipmentsViewModel resultModel = result.Model as SearchVaccineShipmentsViewModel;
            List<VaxShipment> actualVaccineShipments = resultModel.ResultListofVaxShipments;
            actualNumberOfShipments = actualVaccineShipments.Count;

            ///3. Assert
            Assert.Equal(expectedNumberOfShipments, actualNumberOfShipments);
        }


        [Fact]
        public void ShouldSearchVaccineShipmentsByStartDateandEndDate()
        {
            ///1. Arrange           
            int expectedNumberOfShipments = 2;
            int actualNumberOfShipments = 0;
            List<VaxShipment> mockVaccineshipments = CreateMockVaccineShipmentData();
            mockVaccineShipmentRepo.Setup(m => m.ListallVaccineShipments()).Returns(mockVaccineshipments);
            mockfacilityrepo.Setup(m => m.ListofAllFacilities()).Returns(new List<Facility>());

            //ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName"); //list of items


            DateTime startDate = new DateTime(2021, 4, 11);
            DateTime endDate = new DateTime(2021, 4, 15);

            SearchVaccineShipmentsViewModel viewModel = new SearchVaccineShipmentsViewModel();
            viewModel.StartDate = startDate;
            viewModel.EndDate = endDate;
            viewModel.FacilityID = null;
            viewModel.VaccineID = null;

            ///2. Act
            ViewResult result = controller.SearchVaccineShipments(viewModel) as ViewResult;

            SearchVaccineShipmentsViewModel resultModel = result.Model as SearchVaccineShipmentsViewModel;
            List<VaxShipment> actualVaccineShipments = resultModel.ResultListofVaxShipments;
            actualNumberOfShipments = actualVaccineShipments.Count;

            ///3. Assert
            Assert.Equal(expectedNumberOfShipments, actualNumberOfShipments);
        }

        [Fact]
        public void ShouldSearchVaccineShipmentsByStartDateandEndDateandVaccine()
        {
            ///1. Arrange           
            int expectedNumberOfShipments = 1;
            int actualNumberOfShipments = 0;
            List<VaxShipment> mockVaccineshipments = CreateMockVaccineShipmentData();
            mockVaccineShipmentRepo.Setup(m => m.ListallVaccineShipments()).Returns(mockVaccineshipments);
            mockfacilityrepo.Setup(m => m.ListofAllFacilities()).Returns(new List<Facility>());


            DateTime startDate = new DateTime(2021, 4, 11);
            DateTime endDate = new DateTime(2021, 4, 15);
            int vaxID = 12;
            SearchVaccineShipmentsViewModel viewModel = new SearchVaccineShipmentsViewModel();
            viewModel.StartDate = startDate;
            viewModel.EndDate = endDate;
            viewModel.FacilityID = null;
            viewModel.VaccineID = vaxID;

            ///2. Act
            ViewResult result = controller.SearchVaccineShipments(viewModel) as ViewResult;

            SearchVaccineShipmentsViewModel resultModel = result.Model as SearchVaccineShipmentsViewModel;
            List<VaxShipment> actualVaccineShipments = resultModel.ResultListofVaxShipments;
            actualNumberOfShipments = actualVaccineShipments.Count;

            ///3. Assert
            Assert.Equal(expectedNumberOfShipments, actualNumberOfShipments);
        }
         
        [Fact]
        public void ShouldSearchVaccineShipmentsByWithoutFiltering()
        {
            //no restriction criteria

            ///1. Arrange           
            int expectedNumberOfShipments = 6;
            int actualNumberOfShipments = 0;
            List<VaxShipment> mockVaccineshipments = CreateMockVaccineShipmentData();
            mockVaccineShipmentRepo.Setup(m => m.ListallVaccineShipments()).Returns(mockVaccineshipments);
            mockfacilityrepo.Setup(m => m.ListofAllFacilities()).Returns(new List<Facility>());

            SearchVaccineShipmentsViewModel viewModel = new SearchVaccineShipmentsViewModel();

            viewModel.StartDate = null;
            viewModel.EndDate = null;
            viewModel.FacilityID = null;
            viewModel.VaccineID = null;

            ///2. Act
            ViewResult result = controller.SearchVaccineShipments(viewModel) as ViewResult;

            SearchVaccineShipmentsViewModel resultModel = result.Model as SearchVaccineShipmentsViewModel;
            List<VaxShipment> actualVaccineShipments = resultModel.ResultListofVaxShipments;
            actualNumberOfShipments = actualVaccineShipments.Count;

            ///3. Assert
            Assert.Equal(expectedNumberOfShipments, actualNumberOfShipments);
        }











        //mocking  - mock data for testing (Moq)
        public List<VaxShipment> CreateMockVaccineShipmentData()
        {

            List<VaxShipment> mockvaccineShipmentList = new List<VaxShipment>();
            //integrated environment development
            DateTime startdate = new DateTime(2021, 4, 4);

            VaxShipment vaccineShipment = new VaxShipment(1, 11, startdate, 15);
            mockvaccineShipmentList.Add(vaccineShipment);

            vaccineShipment = new VaxShipment(1, 12, startdate, 25);
            mockvaccineShipmentList.Add(vaccineShipment);

            vaccineShipment = new VaxShipment(1, 13, startdate, 35);
            mockvaccineShipmentList.Add(vaccineShipment);

            startdate = new DateTime(2021, 4, 11);

            vaccineShipment = new VaxShipment(2, 11, startdate, 101);
            mockvaccineShipmentList.Add(vaccineShipment);

            DateTime endDate = new DateTime(2021, 4, 15);

            vaccineShipment = new VaxShipment(2, 12, startdate, 151, endDate);
            mockvaccineShipmentList.Add(vaccineShipment);

            vaccineShipment = new VaxShipment(2, 13, startdate, 201, endDate);
            mockvaccineShipmentList.Add(vaccineShipment);

            return mockvaccineShipmentList;

        }

        


    }//end class
}//end name space
