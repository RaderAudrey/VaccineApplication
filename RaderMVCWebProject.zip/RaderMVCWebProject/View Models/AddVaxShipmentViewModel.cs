﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RaderClassLibrary;
using System.ComponentModel.DataAnnotations;


namespace RaderMVCWebProject.View_Models
{
    public class AddVaxShipmentViewModel
    {
        //public int? VaccineShipmentID { get; set; } //autognerated

        [Required(ErrorMessage = "Start Date is Required")]
        [DataType(DataType.Date)]
        public DateTime? StartDate { get; set; } //needed

        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; }//optional

        [Required(ErrorMessage = "Number of Vaccines Shipped is Required")]
        public int? NumberofVaxShip { get; set; } //needed

        //from the drop down lists
        public int FacilityID { get; set; }
        public int VaccineID { get; set; }
    }
}
