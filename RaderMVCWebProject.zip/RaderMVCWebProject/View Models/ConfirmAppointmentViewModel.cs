﻿using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.View_Models
{
    public class ConfirmAppointmentViewModel
    {
        public int AppoinmentAvailabilityID { get; set; }



        public int VaccineID { get; set; }
        public int FacilityID { get; set; }

        [DataType(DataType.Date)]
        public DateTime AppointmentDate { get; set; }

        [DataType(DataType.Time)]
        public DateTime StartTime { get; set; }
        [DataType(DataType.Time)]
        public DateTime? EndTime { get; set; }


        //SearchAvailabilityViewModel: VaccineID, FacilityID, AppointmentDate, StartTime, EndTime

    }
}
