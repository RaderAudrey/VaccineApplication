﻿using RaderMVCWebProject.Models;
using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.View_Models
{
    public class SearchVaccineShipmentsViewModel
    {
        //for user inputs (all are optional)
        public int? VaccineID { get; set; }
        public int? FacilityID { get; set; }


        [DataType(DataType.Date)]
        public DateTime? StartDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; }

        //for result
        public List<VaxShipment> ResultListofVaxShipments {get; set;}
    }
}
