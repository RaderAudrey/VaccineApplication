﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RaderClassLibrary;
using System.ComponentModel.DataAnnotations;

namespace RaderMVCWebProject.View_Models
{
    public class AddVaccineExchangeViewModel
    {
        public DateTime? ExchangedDate { get; set; }

        [Required(ErrorMessage = "Number of Doses in Exchange is Required")]
        public int? ExchangedDoses { get; set; }

        //  SendingFacilityID RecievingFacilityID 


        //drop downs
        public int SendingFacilityID { get; set; }
        public int RecievingFacilityID { get; set; }

        public int VaccineID { get; set; }


    }
}
