﻿using RaderMVCWebProject.Models;
using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.View_Models
{
    public class SearchVaccineExchangeViewModel
    {
        //optional inputs

        public DateTime? ExchangedDate { get; set; }

        public int? ExchangedDoses { get; set; }

        //  SendingFacilityID RecievingFacilityID 


        //drop downs
        public int? SendingFacilityID { get; set; }
        public int? RecievingFacilityID { get; set; }

        public int? VaccineID { get; set; }

        public List<VaccineExchange> ResultListofVaxExchanges { get; set; }

    }
}
