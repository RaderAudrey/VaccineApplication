﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RaderClassLibrary;
using RaderMVCWebProject;

namespace RaderMVCWebProject.View_Models
{
    public class AddAppointmentAvailabilityViewModel
    {

       // public int AppoinmentAvailabilityID { get; set; }

        public DateTime AppointmentStartTime { get; set; }
       // public DateTime AppointmentEndTime { get; set; }

       // public DateTime? AppointmentBooked { get; set; }

      //  public AppointmentStatusOptions? AppointmentStatus { get; set; }
        // open, booked, completed, cancelled, no show


        //realtion DB connections
        public int FacilityInventoryID { get; set; }
     //   public string? PatientID { get; set; }



    }
}
