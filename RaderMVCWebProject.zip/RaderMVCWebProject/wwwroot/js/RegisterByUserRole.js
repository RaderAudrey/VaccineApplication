﻿$(document).ready(

    function ()
    {
        $('#PatientInputs').hide();
        $('#FacilityInputs').hide();

        $('#UserRole').change(

            function ()
            {
                var userRole = $('#UserRole').val();

                if (userRole == 'SelectUserRole') {
                    $('#PatientInputs').hide();
                    $('#FacilityInputs').hide();
                }
                if (userRole == 'Patient') {
                    $('#PatientInputs').show();
                    $('#FacilityInputs').hide();
                }
                if (userRole == 'FacilityAdmin') {
                    $('#PatientInputs').hide();
                    $('#FacilityInputs').show();
                }
            }
        );

    }

);