﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using RaderMVCWebProject.Models;
using RaderClassLibrary;
using RaderMVCWebProject.View_Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace RaderMVCWebProject.Controllers
{
    public class AppointmentSchedulerController : Controller
    {
        private readonly IVaccineExchangeRepo iVaccineExchangeRepo;
        private readonly IFacilityRepo ifacilityRepo;
        private readonly IApplicationUserRepo iApplicationUserRepo;
        private readonly IFacilityInventoryRepo ifacilityInventoryRepo;
        private readonly IAppointmentAvailabilityRepo iappoitnemtnavailabilityRepo;
        public AppointmentSchedulerController(IVaccineExchangeRepo vaccineexchangerepo, IFacilityRepo facilityRepo, IApplicationUserRepo applicationUser, IFacilityInventoryRepo facilityInventory, IAppointmentAvailabilityRepo vaccinationappt)
        {
            this.iVaccineExchangeRepo = vaccineexchangerepo;
            this.ifacilityRepo = facilityRepo;
            this.iApplicationUserRepo = applicationUser;
            this.ifacilityInventoryRepo = facilityInventory;
            this.iappoitnemtnavailabilityRepo = vaccinationappt;
        }
        public IActionResult Index()
        {
            return View();
        }
        
        
        public IActionResult ListAllAppointments()
        {
            List<AppointmentAvailability> allAppts = iappoitnemtnavailabilityRepo.ListAllAppointments();

            if (User.IsInRole("Patient"))
            {
                allAppts = allAppts.Where(a => a.FacilityInventory.CurrentInventory != 0 && a.PatientID == null).ToList();
                return View(allAppts);
            }
            else
            {
                return View(allAppts);

            }

        }

        [Authorize(Roles ="Patient")]
        public IActionResult ListMyAppointments()
        {
            string patientID = iApplicationUserRepo.FindUserID();
            List<AppointmentAvailability> allAppts = iappoitnemtnavailabilityRepo.ListAllAppointments();

            allAppts = allAppts.Where(a => a.PatientID == patientID).ToList();

            return View(allAppts);
        }                

        [HttpGet]
        public ViewResult SearchAvailableAppointments()
        {
            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName");
            SearchAvailabilityViewModel viewModel = new SearchAvailabilityViewModel();
            return View(viewModel);
        }

        [HttpPost]
        public ViewResult SearchAvailableAppointments(SearchAvailabilityViewModel viewmodel)
        {

            List<AppointmentAvailability> PotentialVaccinationAppointments = iappoitnemtnavailabilityRepo.ListAllAppointments();

            //SearchAvailabilityViewModel: VaccineID, FacilityID, AppointmentDate, StartTime, EndTime

            PotentialVaccinationAppointments = PotentialVaccinationAppointments.Where(a => a.FacilityInventory.CurrentInventory != 0 && a.PatientID == null).ToList();

            PotentialVaccinationAppointments = PotentialVaccinationAppointments.OrderBy(a=> a.AppointmentStartTime).ToList();


            if (viewmodel.VaccineID != null)
            {
                PotentialVaccinationAppointments = PotentialVaccinationAppointments.Where(a => a.FacilityInventory.VaccineID == viewmodel.VaccineID).ToList();
            }
            if (viewmodel.FacilityID != null)
            {
                PotentialVaccinationAppointments = PotentialVaccinationAppointments.Where(a => a.FacilityInventory.FacilityID == viewmodel.FacilityID).ToList();
            }
            if (viewmodel.AppointmentDate != null)
            {
                PotentialVaccinationAppointments = PotentialVaccinationAppointments.Where(a => a.AppointmentStartTime.Date == viewmodel.AppointmentDate).ToList();
            }
            if (viewmodel.StartTime != null)
            {
                PotentialVaccinationAppointments = PotentialVaccinationAppointments.Where(a => a.AppointmentStartTime.TimeOfDay >= viewmodel.StartTime.Value.TimeOfDay).ToList();
            }
            if (viewmodel.EndTime != null)
            {
                PotentialVaccinationAppointments = PotentialVaccinationAppointments.Where(a => a.AppointmentEndTime.TimeOfDay <= viewmodel.EndTime.Value.TimeOfDay).ToList();
            }

            viewmodel.ResultListAppts = PotentialVaccinationAppointments;
            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName");


            return View(viewmodel);
        }



      
        public IActionResult ScheduleAppoinment(int AppoinmentAvailabilityID)
        {
            AppointmentAvailability appintmentAvailability = iappoitnemtnavailabilityRepo.FindAppointmentAvailability(AppoinmentAvailabilityID);


            FacilityInventory facilityinventory = ifacilityInventoryRepo.FindFacilityInventory(appintmentAvailability.FacilityInventoryID);
            int currentinventory = facilityinventory.CurrentInventory;


            if (appintmentAvailability.PatientID != null)
            {
                ModelState.AddModelError("AppointmentTaken", "The Appointment: " + appintmentAvailability.AppointmentStartTime.ToShortDateString() +" at " + appintmentAvailability.AppointmentStartTime.ToShortTimeString() + " for "+ 
                  facilityinventory.Vaccine.Name + " at Facility: "+ 
                  facilityinventory.Facility.FacilityName + " is already taken");
            }

            if (currentinventory == 0)
            {
                ModelState.AddModelError("NoInventory", "There is no inventory of " + appintmentAvailability.FacilityInventory.Vaccine.Name + " at " + " Facility: " + appintmentAvailability.FacilityInventory.Facility.FacilityName);
            }

            if (ModelState.IsValid)
            {
                string patientID =
                iApplicationUserRepo.FindUserID();

                appintmentAvailability.PatientID = patientID;
                appintmentAvailability.AppointmentBooked = DateTime.Now;
                appintmentAvailability.AppointmentStatus = AppointmentStatusOptions.Booked;

                iappoitnemtnavailabilityRepo.ScheduleAppointment(appintmentAvailability);

                facilityinventory.CurrentInventory -= 1;
                ifacilityInventoryRepo.UpdateCurrentInventory(facilityinventory);

                return RedirectToAction("ListMyAppointments");
            }
            else
            {
                return RedirectToAction("SearchAvailableAppointments");
            }            
        }

        //MakeNewAppointmentAvailability

        [HttpGet]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult MakeNewAppointmentAvailability()
        {
            //ViewData["FacilityInventory"] = new SelectList(ifacilityInventoryRepo.ListallAvailableAppointments(), "FacilityInventoryID", "FacilityName");

            return View();
        }

        [HttpPost]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult MakeNewAppointmentAvailability(AddAppointmentAvailabilityViewModel viewModel)
        {
            //string facilityAdminID = iApplicationUserRepo.FindUserID();
            FacilityInventory facilityinventory = ifacilityInventoryRepo.FindFacilityInventory(viewModel.FacilityInventoryID);
            int currentinventory = facilityinventory.CurrentInventory;

            if (currentinventory == 0)
            {
                ModelState.AddModelError("NoInventory", "There is no inventory of the selected Vaccine at this location");
            }

            if (ModelState.IsValid)
            {
                AppointmentAvailability appointmentAvailability = new AppointmentAvailability(viewModel.FacilityInventoryID, viewModel.AppointmentStartTime);

                //should implement FailityAdmin ID tracking for this as well

                int appointmentAvailabilityID = iappoitnemtnavailabilityRepo.AddAppointmentAvailability(appointmentAvailability);


                appointmentAvailability.AppoinmentAvailabilityID = appointmentAvailabilityID; // only for the test data


                return RedirectToAction("ListAllAppointments");
            }
            else
            {
                //ViewData["FacilityInventory"] = new SelectList(ifacilityInventoryRepo.ListallAvailableAppointments(), "FacilityInventoryID", "FacilityName");

                return View(viewModel);
            }
        }


        //EditAppointment

        [HttpGet]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult EditAppointment(int AppoinmentAvailabilityID)
        {
            AppointmentAvailability appointmentAvailability = iappoitnemtnavailabilityRepo.FindAppointmentAvailability(AppoinmentAvailabilityID);

            return View(appointmentAvailability);
        }

        [HttpPost]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult EditAppointment(AppointmentAvailability appointmentAvailability)
        {
            if (ModelState.IsValid)
            {
                iappoitnemtnavailabilityRepo.EditAppointment(appointmentAvailability);

                return RedirectToAction("ListAllAppointments");
            }
            else
            {
                return View(appointmentAvailability);
            }
        }

        


        [HttpGet]
        public IActionResult DeleteAppointment(int AppoinmentAvailabilityID)
        {
            AppointmentAvailability appointmentAvailability = iappoitnemtnavailabilityRepo.FindAppointmentAvailability(AppoinmentAvailabilityID);

            return View(appointmentAvailability);
        }

        [HttpPost]
        public IActionResult DeleteAppointment(AppointmentAvailability appointmentAvailability)
        {
            if (ModelState.IsValid)
            {
                iappoitnemtnavailabilityRepo.DeleteAppointment(appointmentAvailability);

                return RedirectToAction("ListAllAppointments");
            }
            else
            {
                return RedirectToAction("ListAllAppointments");
            }
        }


        //PatientCancelAppointment

        //to show a patient that they have cancelled an appointment but also open it to other patients,
        //you need to take the info in the appointmentAvailability object and duplicate it in a new object while setting the old object status to "cancelled"
        [HttpGet]
        public IActionResult PatientCancelAppointment(int AppoinmentAvailabilityID)
        {
            AppointmentAvailability appointmentAvailability = iappoitnemtnavailabilityRepo.FindAppointmentAvailability(AppoinmentAvailabilityID);

            return View(appointmentAvailability);

        }

        [HttpPost]
        public IActionResult PatientCancelAppointment(AppointmentAvailability appointmentAvailability)
        {          
            FacilityInventory facilityinventory = ifacilityInventoryRepo.FindFacilityInventory(appointmentAvailability.FacilityInventoryID);

            if (appointmentAvailability.AppointmentStatus != AppointmentStatusOptions.Booked)
            {
                ModelState.AddModelError("ApppintmentStatusError", "The appointment on: " + appointmentAvailability.AppointmentStartTime+ " cannot be cancelled as its status is:" + appointmentAvailability.AppointmentStatus);
            }

            //if (appointmentAvailability.AppointmentStartTime >= DateTime.Now)
            //{
            //    ModelState.AddModelError("AppointmentPassed", "The appointment cannot be cancelled after Start Time");
            //}

            if (ModelState.IsValid)
            {
                //set status to cancelled
                appointmentAvailability.AppointmentStatus = AppointmentStatusOptions.Cancelled;
                iappoitnemtnavailabilityRepo.EditAppointment(appointmentAvailability);

                //add back inventory for facility
                facilityinventory.CurrentInventory += 1;
                ifacilityInventoryRepo.UpdateCurrentInventory(facilityinventory);


                //create duplicate appointment with different primary key, with an open status
                AppointmentAvailability newappointmentavailavbility = new AppointmentAvailability(appointmentAvailability.FacilityInventoryID, appointmentAvailability.AppointmentStartTime);
                newappointmentavailavbility.AppointmentStatus = AppointmentStatusOptions.Open;

                iappoitnemtnavailabilityRepo.AddAppointmentAvailability(newappointmentavailavbility);

                return RedirectToAction("ListMyAppointments");
            }
            else
            {
                return RedirectToAction("ListMyAppointments");
            }
        }




    }
}

