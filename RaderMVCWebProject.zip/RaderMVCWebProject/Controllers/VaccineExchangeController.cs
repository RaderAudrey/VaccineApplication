﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using RaderMVCWebProject.Models;
using RaderClassLibrary;
using RaderMVCWebProject.View_Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Controllers
{
    public class VaccineExchangeController : Controller
    {
        private readonly IVaccineExchangeRepo iVaccineExchangeRepo;
        private readonly IFacilityRepo ifacilityRepo;
        private readonly IApplicationUserRepo iApplicationUserRepo;
        private readonly IFacilityInventoryRepo ifacilityInventoryRepo;

        public VaccineExchangeController(IVaccineExchangeRepo vaccineexchangerepo, IFacilityRepo facilityRepo, IApplicationUserRepo applicationUser, IFacilityInventoryRepo facilityInventory)
        {
            this.iVaccineExchangeRepo = vaccineexchangerepo;
            this.ifacilityRepo = facilityRepo;
            this.iApplicationUserRepo = applicationUser;
            this.ifacilityInventoryRepo = facilityInventory;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "FacilityManager")]
        public IActionResult ListallVaccineExchanges()
        {
            List<VaccineExchange> allVaccineExchanges = iVaccineExchangeRepo.ListallVaccineExchanges();
            return View(allVaccineExchanges);
        }

        [HttpGet]
        public ViewResult SearchVaccineExchanges()
        {
            
            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName"); 

            SearchVaccineExchangeViewModel viewModel = new SearchVaccineExchangeViewModel();

            return View(viewModel);
        }


        //metthod that gives result
        [HttpPost]
        public ViewResult SearchVaccineExchanges(SearchVaccineExchangeViewModel viewmodel)
        {
            List<VaccineExchange> allVaccineExchanges = iVaccineExchangeRepo.ListallVaccineExchanges();
            //  SendingFacilityID RecievingFacilityID 

            if (viewmodel.VaccineID != null)
            {
                allVaccineExchanges = allVaccineExchanges.Where(a => a.VaccineID == viewmodel.VaccineID).ToList();
            }
            if (viewmodel.SendingFacilityID != null)
            {
                allVaccineExchanges = allVaccineExchanges.Where(a => a.SendingFacilityID == viewmodel.SendingFacilityID).ToList();
            }
            if (viewmodel.RecievingFacilityID != null)
            {
                allVaccineExchanges = allVaccineExchanges.Where(a => a.RecievingFacilityID == viewmodel.RecievingFacilityID).ToList();
            }
            if (viewmodel.ExchangedDate != null)
            {
                allVaccineExchanges = allVaccineExchanges.Where(a => a.ExchangedDate == viewmodel.ExchangedDate).ToList();
            }
            if (viewmodel.ExchangedDoses != null)
            {
                allVaccineExchanges = allVaccineExchanges.Where(a => a.ExchangedDoses == viewmodel.ExchangedDoses).ToList();
            }

            viewmodel.ResultListofVaxExchanges = allVaccineExchanges;

            //dynamic dropdowns
            //list of all facilities

            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName"); //list of items

            return View(viewmodel);

        }




        [HttpGet]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult MakeVaccineExchange()
        {
            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName"); 

            return View();
        }
    
        [HttpPost]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult MakeVaccineExchange(AddVaccineExchangeViewModel viewModel)
        {
            if(viewModel.SendingFacilityID == viewModel.RecievingFacilityID)
            {
                ModelState.AddModelError("SameFacilityError", "The Sending Facility and recieving facility cannot be the same");
            }

            FacilityInventory sendingfacilityinventory = ifacilityInventoryRepo.FindFacilityInventory(viewModel.SendingFacilityID, viewModel.VaccineID);

            FacilityInventory recievingfacilityinventory = ifacilityInventoryRepo.FindFacilityInventory(viewModel.RecievingFacilityID, viewModel.VaccineID);

            int currentsentingfacilityinventory = sendingfacilityinventory.CurrentInventory;


            if (viewModel.ExchangedDoses > currentsentingfacilityinventory)
            {
                ModelState.AddModelError("NotEnoughVaccines", "The amount you are trying to send is more than is currently in inventory ofsending facility");
            }

            if (ModelState.IsValid)
            {
                VaccineExchange vaccineExchange = new VaccineExchange(viewModel.ExchangedDoses.Value, viewModel.VaccineID, viewModel.SendingFacilityID, viewModel.RecievingFacilityID);

                int vaccineExchangeID = iVaccineExchangeRepo.MakeVaccineExchange(vaccineExchange);

                sendingfacilityinventory.CurrentInventory -= viewModel.ExchangedDoses.Value;
                recievingfacilityinventory.CurrentInventory += viewModel.ExchangedDoses.Value;

                //add to current inventory of recieving
                ifacilityInventoryRepo.UpdateCurrentInventory(sendingfacilityinventory);
                //subtract from current inventory of sending
                ifacilityInventoryRepo.UpdateCurrentInventory(recievingfacilityinventory);


                vaccineExchange.VaccineExchangeID = vaccineExchangeID; // only for the test data

                return RedirectToAction("ListallVaccineExchanges");
            }
            else
            {
                ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName");

                return View(viewModel);
            }
        }





    }
}
