﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using RaderMVCWebProject.Models;
using RaderClassLibrary;
using RaderMVCWebProject.View_Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Controllers
{
    public class VaccineShipmentController : Controller
    {
        private readonly IVaccineShipmentRepo iVaccineShipmentRepo;
        private readonly IFacilityRepo ifacilityRepo;
        private readonly IApplicationUserRepo iApplicationUserRepo;
        private readonly IFacilityInventoryRepo ifacilityInventoryRepo;

        public VaccineShipmentController(IVaccineShipmentRepo vaccineShipmentRepo, IFacilityRepo facilityRepo, IApplicationUserRepo applicationUser, IFacilityInventoryRepo facilityInventory)
        {
            this.iVaccineShipmentRepo = vaccineShipmentRepo;
            this.ifacilityRepo = facilityRepo;
            this.iApplicationUserRepo = applicationUser;
            this.ifacilityInventoryRepo = facilityInventory;
        }

        public IActionResult Index()
        {
            return View();
        }


        [Authorize(Roles = "FacilityManager")]
        public IActionResult ListallVaccineShipments()
        {
            List<VaxShipment> allVaccineShipments = iVaccineShipmentRepo.ListallVaccineShipments();
            return View(allVaccineShipments);
        }




        //metthod  to get user input
        [HttpGet]
        public ViewResult SearchVaccineShipments()
        {
            //dynamic dropdowns
            //list of all facilities

            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName"); //list of items, value ie ID for items, and the value of the name for items

            SearchVaccineShipmentsViewModel viewModel = new SearchVaccineShipmentsViewModel();

            return View(viewModel);
        }



        //metthod that gives result
        [HttpPost]
        public ViewResult SearchVaccineShipments(SearchVaccineShipmentsViewModel viewmodel)
        {
            List<VaxShipment> allVaccineShipments = iVaccineShipmentRepo.ListallVaccineShipments();

            if (viewmodel.VaccineID != null)
            {
                allVaccineShipments = allVaccineShipments.Where(a => a.VaccineID == viewmodel.VaccineID).ToList();
            }
            if (viewmodel.FacilityID != null)
            {
                allVaccineShipments = allVaccineShipments.Where(a => a.FacilityID == viewmodel.FacilityID).ToList();
            }
            if (viewmodel.StartDate != null)
            {
                allVaccineShipments = allVaccineShipments.Where(a => a.StartDate >= viewmodel.StartDate).ToList();
            }
            if (viewmodel.EndDate != null)
            {
                allVaccineShipments = allVaccineShipments.Where(a => a.EndDate <= viewmodel.EndDate).ToList();
            }

            viewmodel.ResultListofVaxShipments = allVaccineShipments;

            //dynamic dropdowns
            //list of all facilities

            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName"); //list of items

            return View(viewmodel);

        }

        //method to input new data
        [HttpGet]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult AddVaccineShipment()
        {
            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName"); //list of items, value ie ID for items, and 

            return View();
        }

        [HttpPost]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult AddVaccineShipment(AddVaxShipmentViewModel viewModel)
        {
            string facilityAdminID = iApplicationUserRepo.FindUserID();

            if (ModelState.IsValid)
            {
                VaxShipment vaxShipment = new VaxShipment(viewModel.FacilityID, viewModel.VaccineID, viewModel.StartDate.Value, viewModel.NumberofVaxShip.Value, viewModel.EndDate);

                vaxShipment.FacilityAdminID = facilityAdminID; //test data

                int vaccineShipmentID = iVaccineShipmentRepo.AddVaccineShipment(vaxShipment);

                FacilityInventory facilityInventory = ifacilityInventoryRepo.FindFacilityInventory(viewModel.FacilityID, viewModel.VaccineID);

                facilityInventory.CurrentInventory += viewModel.NumberofVaxShip.Value;

                //add to current inventory counter
                ifacilityInventoryRepo.UpdateCurrentInventory(facilityInventory);

                vaxShipment.VaccineShipmentID = vaccineShipmentID; // only for the test data


                return RedirectToAction("ListallVaccineShipments");
            }
            else
            {
                ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName");

                return View(viewModel);
            }
        }




        //edit method
        [HttpGet]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult EditVaccineShipment(int vaxShipmentID)
        {
            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName");

            VaxShipment vaccineshipment = iVaccineShipmentRepo.FindVaccineShipment(vaxShipmentID);

            return View(vaccineshipment);
        }

        [HttpPost]
        [Authorize(Roles = "FacilityManager")]
        public IActionResult EditVaccineShipment(VaxShipment vaxShipment)
        {
            if (ModelState.IsValid)
            {                
                iVaccineShipmentRepo.EditVaccineShipment(vaxShipment);

                return RedirectToAction("ListallVaccineShipments");
            }
            else
            {
                ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName");

                return View(vaxShipment);
            }
        }



        //delete
        [HttpGet]
        public IActionResult DeleteVaccineShipment(int vaxShipmentID)
        {
            ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName");

            VaxShipment vaccineshipment = iVaccineShipmentRepo.FindVaccineShipment(vaxShipmentID);

            return View(vaccineshipment);
        }

        [HttpPost]
        public IActionResult DeleteVaccineShipment(VaxShipment vaxShipment)
        {
            if (ModelState.IsValid)
            {
                iVaccineShipmentRepo.DeleteVaccineShipment(vaxShipment);

                return RedirectToAction("ListallVaccineShipments");
            }
            else
            {
                ViewData["AllFacilities"] = new SelectList(ifacilityRepo.ListofAllFacilities(), "FacilityID", "FacilityName");

                return RedirectToAction("ListallVaccineShipments");
            }
        }
        



        //public void ShouldSearchVaccineShipments(DateTime? startDate = null)//required input
        //{
        //    List<VaxShipment> allVaccineShipments = iVaccineShipmentRepo.ListallVaccineShipments();

        //    if(startDate != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.StartDate >= startDate).ToList();
        //    }

        //    return View(allVaccineShipments);
        //}




        //public void ShouldSearchVaccineShipmentsByStartDateandEndDate(DateTime? startDate = null, DateTime? endDate = null)
        //{
        //    List<VaxShipment> allVaccineShipments = iVaccineShipmentRepo.ListallVaccineShipments();

        //    if (startDate != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.StartDate >= startDate).ToList();
        //    }
        //    if (endDate != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.EndDate <= endDate).ToList();
        //    }

        //    return View(allVaccineShipments);
        //}



        //public void ShouldSearchVaccineShipmentsByStartDateandEndDateandVaccine(DateTime? startDate = null, DateTime? endDate = null, int? vaxID = null)
        //{
        //    List<VaxShipment> allVaccineShipments = iVaccineShipmentRepo.ListallVaccineShipments();

        //    if (vaxID != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.VaccineID == vaxID).ToList();
        //    }
        //    if (startDate != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.StartDate >= startDate).ToList();
        //    }
        //    if (endDate != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.EndDate <= endDate).ToList();
        //    }

        //    return View(allVaccineShipments);

        //}

        //public void ShouldSearchVaccineShipmentsByStartDateandEndDateandVaccineandFacility(DateTime? startDate = null, DateTime? endDate = null, int? vaxID = null, int? facID = null)
        //{
        //    List<VaxShipment> allVaccineShipments = iVaccineShipmentRepo.ListallVaccineShipments();

        //    if (vaxID != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.VaccineID == vaxID).ToList();
        //    }
        //    if (facID != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.FacilityID == facID).ToList();
        //    }
        //    if (startDate != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.StartDate >= startDate).ToList();
        //    }
        //    if (endDate != null)
        //    {
        //        allVaccineShipments = allVaccineShipments.Where(a => a.EndDate <= endDate).ToList();
        //    }

        //    return View(allVaccineShipments);
        //}

        public ViewResult ShouldSearchVaccineShipmentsByWithoutFiltering()
        {
            List<VaxShipment> allVaccineShipments = iVaccineShipmentRepo.ListallVaccineShipments();
            return View(allVaccineShipments);
        }
    }// end class
}//end namespace
