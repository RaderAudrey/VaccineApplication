﻿using Microsoft.EntityFrameworkCore;
using RaderMVCWebProject.Data;
using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Models
{
    public class FacilityInventoryRepo : IFacilityInventoryRepo
    {
        private readonly ApplicationDbContext database;

        public FacilityInventoryRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public FacilityInventory FindFacilityInventory(int facilityID, int vaccineID)
        {
            FacilityInventory facinv =
            database.FacilityInventory.Where(f => f.FacilityID == facilityID && f.VaccineID == vaccineID).FirstOrDefault();

            return facinv;
        }

        public FacilityInventory FindFacilityInventory(int facilityinventoryID)
        {
            FacilityInventory facinv =
           database.FacilityInventory
            .Include(fi => fi.Vaccine)
            .Include(fi => fi.Facility)
            .Where(fi => fi.FacilityInventoryID == facilityinventoryID)
            .FirstOrDefault();

            return facinv;
        }

        public List<FacilityInventory> ListallAvailableAppointments()
        {
            return database.FacilityInventory
              .Include(fi => fi.Vaccine)
              .Include(fi => fi.Facility)
              .ToList();
        }

        //public int? GetCurrentInventory(int facilityID, int vaccineID)
        //{                        
        //    int?currentinventory = 0;
        //    if(facinv != null)
        //    {
        //        currentinventory = facinv.CurrentInventory;
        //    }
        //    return currentinventory;
        //}

        public void UpdateCurrentInventory(FacilityInventory facilityInventory)
        {
            database.FacilityInventory.Update(facilityInventory);
            database.SaveChanges();
        }

    }
}
