﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Models
{
    public class ApplicationUserRepo : IApplicationUserRepo
    {

        private IHttpContextAccessor httpContext;

        public ApplicationUserRepo(IHttpContextAccessor contextAccessor)
        {
            this.httpContext = contextAccessor;
        }


        public string FindUserID()
        {
            string userID = httpContext.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            return userID;
        }
    }
}
