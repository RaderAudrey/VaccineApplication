﻿using Microsoft.EntityFrameworkCore;
using RaderClassLibrary;
using RaderMVCWebProject.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Models
{
    public class AppointmentAvailabilityRepo : IAppointmentAvailabilityRepo
    {
        private readonly ApplicationDbContext database;

        public AppointmentAvailabilityRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public int AddAppointmentAvailability(AppointmentAvailability appintmentAvailability)
        {
            database.AppointmentAvailability.Add(appintmentAvailability);
            database.SaveChanges();
            return appintmentAvailability.AppoinmentAvailabilityID;
        }

        public void DeleteAppointment(AppointmentAvailability appointmentAvailability)
        {
            database.AppointmentAvailability.Remove(appointmentAvailability);
            database.SaveChanges();
        }

        public void EditAppointment(AppointmentAvailability appointmentAvailability)
        {
            database.AppointmentAvailability.Update(appointmentAvailability);
            database.SaveChanges();
        }

        public AppointmentAvailability FindAppointmentAvailability(int appointmentAvailabilityID)
        {
            AppointmentAvailability appointment = database.AppointmentAvailability
               .Include(aa => aa.FacilityInventory)
               .Include(aa => aa.FacilityInventory.Facility)
               .Include(aa => aa.FacilityInventory.Vaccine)
               .Include(aa => aa.Patient)
               .Where(aa => aa.AppoinmentAvailabilityID == appointmentAvailabilityID)
               .FirstOrDefault();

            ;
            return (appointment);
        }

        public List<AppointmentAvailability> ListAllAppointments()
        {
            return database.AppointmentAvailability
               .Include(aa => aa.FacilityInventory)
               .Include(aa => aa.FacilityInventory.Facility)
               .Include(aa => aa.FacilityInventory.Vaccine)
               .Include(aa => aa.Patient)
               .ToList();
        }

        public void ScheduleAppointment(AppointmentAvailability appintmentAvailability)
        {
            database.AppointmentAvailability.Update(appintmentAvailability);
            database.SaveChanges();
        }
    }
}
