﻿using RaderMVCWebProject.Data;
using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Models
{
    public class FacilityRepo : IFacilityRepo
    {
        private readonly ApplicationDbContext database;

        public FacilityRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public Facility FindFacility(int facilityID)
        {
            Facility facility = database.Facility.Find(facilityID);
            return facility;

        }

        public List<Facility> ListofAllFacilities()
        {
            return database.Facility.ToList();
        }



    }
}
