﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RaderClassLibrary;

namespace RaderMVCWebProject.Models
{
    public interface IFacilityRepo
    {
        List<Facility> ListofAllFacilities();
        Facility FindFacility(int facilityID);
    }
}
