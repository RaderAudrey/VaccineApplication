﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RaderClassLibrary;

namespace RaderMVCWebProject.Models
{
    public interface IFacilityInventoryRepo
    {
        //revisit later
        //refactoring: make it work, make it cleaner and more efficient
        void UpdateCurrentInventory(FacilityInventory facilityInventory);
        //int? GetCurrentInventory(int facilityID, int vaccineID);

        FacilityInventory FindFacilityInventory(int facilityID, int vaccineID);
        FacilityInventory FindFacilityInventory(int facilityinventoryID);
        List<FacilityInventory> ListallAvailableAppointments();
    }
}
