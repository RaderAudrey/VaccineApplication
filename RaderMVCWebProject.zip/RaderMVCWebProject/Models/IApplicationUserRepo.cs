﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RaderClassLibrary;

namespace RaderMVCWebProject.Models
{
    public interface IApplicationUserRepo
    {
        string FindUserID();

    }
}
