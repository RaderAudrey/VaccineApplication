﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RaderClassLibrary;

namespace RaderMVCWebProject.Models
{
    public interface IVaccineShipmentRepo
    {
        //method signatures (what needs to be done, but not how they will be done)

        List<VaxShipment> ListallVaccineShipments();
        int AddVaccineShipment(VaxShipment vaxShipment);
        VaxShipment FindVaccineShipment(int vaxShipmentID);
        void EditVaccineShipment(VaxShipment vaxShipment);
        void DeleteVaccineShipment(VaxShipment vaxShipment);
    }
}
