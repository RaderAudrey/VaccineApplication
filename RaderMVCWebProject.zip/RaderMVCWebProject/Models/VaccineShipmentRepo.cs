﻿using Microsoft.EntityFrameworkCore;
using RaderMVCWebProject.Data;
using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Models
{
    public class VaccineShipmentRepo : IVaccineShipmentRepo //this class implements the interface
    {
        private readonly ApplicationDbContext database;

        public VaccineShipmentRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public int AddVaccineShipment(VaxShipment vaxShipment)
        {
            database.VaxShipment.Add(vaxShipment);
            database.SaveChanges();
            return vaxShipment.VaccineShipmentID;
        }

        public void DeleteVaccineShipment(VaxShipment vaxShipment)
        {
            database.VaxShipment.Remove(vaxShipment);
            database.SaveChanges();
        }

        public void EditVaccineShipment(VaxShipment vaxShipment)
        {
            database.VaxShipment.Update(vaxShipment);
            database.SaveChanges();
        }

        public VaxShipment FindVaccineShipment(int vaxShipmentID)
        {
            VaxShipment vaxShipment =
            database.VaxShipment.Find(vaxShipmentID);

            return vaxShipment;
        }

        public List<VaxShipment> ListallVaccineShipments()
        {
            return database.VaxShipment
                .Include(vs => vs.Vaccine)
                .Include(vs => vs.Facility)
                .ToList();
        }
    }
}
