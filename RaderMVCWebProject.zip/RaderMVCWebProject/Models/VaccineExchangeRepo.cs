﻿using Microsoft.EntityFrameworkCore;
using RaderMVCWebProject.Data;
using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Models
{
    public class VaccineExchangeRepo : IVaccineExchangeRepo
    {
        private readonly ApplicationDbContext database;

        public VaccineExchangeRepo(ApplicationDbContext dbContext)
        {
            this.database = dbContext;
        }

        public List<VaccineExchange> ListallVaccineExchanges()
        {        //  SendingFacilityID RecievingFacilityID 

            return database.VaccineExchange
               .Include(vs => vs.Vaccine)
               .Include(vs => vs.SendingFacility)
               .Include(vs => vs.RecivingFacility)
               .ToList();
        }

        public int MakeVaccineExchange(VaccineExchange vaccineExchange)
        {
            database.VaccineExchange.Add(vaccineExchange);
            database.SaveChanges();           
            return vaccineExchange.VaccineExchangeID;
        }
       

    }
}
