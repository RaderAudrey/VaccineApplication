﻿using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Models
{
    public interface IAppointmentAvailabilityRepo
    {
        AppointmentAvailability FindAppointmentAvailability(int appointmentAvailabilityID);
        void ScheduleAppointment(AppointmentAvailability appintmentAvailability);
        List<AppointmentAvailability> ListAllAppointments();
        int AddAppointmentAvailability(AppointmentAvailability appintmentAvailability);
        void EditAppointment(AppointmentAvailability appointmentAvailability);
        void DeleteAppointment(AppointmentAvailability appointmentAvailability);
    }
}
