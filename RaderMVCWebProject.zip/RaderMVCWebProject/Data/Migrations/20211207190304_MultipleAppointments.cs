﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RaderMVCWebProject.Data.Migrations
{
    public partial class MultipleAppointments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MultipleAppointmentScheduler",
                columns: table => new
                {
                    MultipleAppointmentSchedulerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SchedulerDateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PatientID = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MultipleAppointmentScheduler", x => x.MultipleAppointmentSchedulerID);
                    table.ForeignKey(
                        name: "FK_MultipleAppointmentScheduler_AspNetUsers_PatientID",
                        column: x => x.PatientID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "AppointmentAvailabilityAlternate",
                columns: table => new
                {
                    AppointmentAvailabilityAlternateID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MultipleAppointmentSchedulerID = table.Column<int>(type: "int", nullable: true),
                    AppointmentDateStartTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppointmentEndTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppointmentStatus = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppointmentAvailabilityAlternate", x => x.AppointmentAvailabilityAlternateID);
                    table.ForeignKey(
                        name: "FK_AppointmentAvailabilityAlternate_MultipleAppointmentScheduler_MultipleAppointmentSchedulerID",
                        column: x => x.MultipleAppointmentSchedulerID,
                        principalTable: "MultipleAppointmentScheduler",
                        principalColumn: "MultipleAppointmentSchedulerID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AppointmentAvailabilityAlternate_MultipleAppointmentSchedulerID",
                table: "AppointmentAvailabilityAlternate",
                column: "MultipleAppointmentSchedulerID");

            migrationBuilder.CreateIndex(
                name: "IX_MultipleAppointmentScheduler_PatientID",
                table: "MultipleAppointmentScheduler",
                column: "PatientID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AppointmentAvailabilityAlternate");

            migrationBuilder.DropTable(
                name: "MultipleAppointmentScheduler");
        }
    }
}
