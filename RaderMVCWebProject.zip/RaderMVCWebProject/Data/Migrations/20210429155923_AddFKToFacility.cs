﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RaderMVCWebProject.Data.Migrations
{
    public partial class AddFKToFacility : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Facility_FacilityID",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_FacilityID",
                table: "AspNetUsers");

            migrationBuilder.AddColumn<string>(
                name: "FacilityAdminID",
                table: "Facility",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Facility_FacilityAdminID",
                table: "Facility",
                column: "FacilityAdminID",
                unique: true,
                filter: "[FacilityAdminID] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_Facility_AspNetUsers_FacilityAdminID",
                table: "Facility",
                column: "FacilityAdminID",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Facility_AspNetUsers_FacilityAdminID",
                table: "Facility");

            migrationBuilder.DropIndex(
                name: "IX_Facility_FacilityAdminID",
                table: "Facility");

            migrationBuilder.DropColumn(
                name: "FacilityAdminID",
                table: "Facility");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_FacilityID",
                table: "AspNetUsers",
                column: "FacilityID");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Facility_FacilityID",
                table: "AspNetUsers",
                column: "FacilityID",
                principalTable: "Facility",
                principalColumn: "FacilityID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
