﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RaderMVCWebProject.Data.Migrations
{
    public partial class AddAppointmentAvailabilityClass : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropTable(
            //    name: "VaccinationAppointment");

            migrationBuilder.CreateTable(
                name: "AppointmentAvailability",
                columns: table => new
                {
                    AppoinmentAvailabilityID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AppointmentStartTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppointmentEndTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppointmentBooked = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AppointmentStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FacilityInventoryID = table.Column<int>(type: "int", nullable: false),
                    PatientID = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppointmentAvailability", x => x.AppoinmentAvailabilityID);
                    table.ForeignKey(
                        name: "FK_AppointmentAvailability_AspNetUsers_PatientID",
                        column: x => x.PatientID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_AppointmentAvailability_FacilityInventory_FacilityInventoryID",
                        column: x => x.FacilityInventoryID,
                        principalTable: "FacilityInventory",
                        principalColumn: "FacilityInventoryID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AppointmentAvailability_FacilityInventoryID",
                table: "AppointmentAvailability",
                column: "FacilityInventoryID");

            migrationBuilder.CreateIndex(
                name: "IX_AppointmentAvailability_PatientID",
                table: "AppointmentAvailability",
                column: "PatientID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AppointmentAvailability");

            //migrationBuilder.CreateTable(
            //    name: "VaccinationAppointment",
            //    columns: table => new
            //    {
            //        VaccinationAppoinmentID = table.Column<int>(type: "int", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        AppointmentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        FacilityID = table.Column<int>(type: "int", nullable: false),
            //        Id = table.Column<string>(type: "nvarchar(450)", nullable: true),
            //        VaccineID = table.Column<int>(type: "int", nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_VaccinationAppointment", x => x.VaccinationAppoinmentID);
            //        table.ForeignKey(
            //            name: "FK_VaccinationAppointment_AspNetUsers_Id",
            //            column: x => x.Id,
            //            principalTable: "AspNetUsers",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //        table.ForeignKey(
            //            name: "FK_VaccinationAppointment_Facility_FacilityID",
            //            column: x => x.FacilityID,
            //            principalTable: "Facility",
            //            principalColumn: "FacilityID",
            //            onDelete: ReferentialAction.Cascade);
            //        table.ForeignKey(
            //            name: "FK_VaccinationAppointment_Vaccine_VaccineID",
            //            column: x => x.VaccineID,
            //            principalTable: "Vaccine",
            //            principalColumn: "VaccineID",
            //            onDelete: ReferentialAction.Cascade);
            //    });

            //migrationBuilder.CreateIndex(
            //    name: "IX_VaccinationAppointment_FacilityID",
            //    table: "VaccinationAppointment",
            //    column: "FacilityID");

            //migrationBuilder.CreateIndex(
            //    name: "IX_VaccinationAppointment_Id",
            //    table: "VaccinationAppointment",
            //    column: "Id");

            //migrationBuilder.CreateIndex(
            //    name: "IX_VaccinationAppointment_VaccineID",
            //    table: "VaccinationAppointment",
            //    column: "VaccineID");
        }
    }
}
