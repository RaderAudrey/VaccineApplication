﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RaderMVCWebProject.Data.Migrations
{
    public partial class AddedFacilityManager : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "FacilityID",
                table: "AspNetUsers",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_FacilityID",
                table: "AspNetUsers",
                column: "FacilityID");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Facility_FacilityID",
                table: "AspNetUsers",
                column: "FacilityID",
                principalTable: "Facility",
                principalColumn: "FacilityID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Facility_FacilityID",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_FacilityID",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "FacilityID",
                table: "AspNetUsers");
        }
    }
}
