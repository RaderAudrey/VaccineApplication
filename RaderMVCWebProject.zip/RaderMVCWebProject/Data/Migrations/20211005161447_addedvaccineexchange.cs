﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RaderMVCWebProject.Data.Migrations
{
    public partial class addedvaccineexchange : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "VaccineExchange",
                columns: table => new
                {
                    VaccineExchangeID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ExchangedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExchangedDoses = table.Column<int>(type: "int", nullable: false),
                    SendingFacilityID = table.Column<int>(type: "int", nullable: false),
                    RecievingFacilityID = table.Column<int>(type: "int", nullable: false),
                    VaccineID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VaccineExchange", x => x.VaccineExchangeID);
                    table.ForeignKey(
                        name: "FK_VaccineExchange_Facility_RecievingFacilityID",
                        column: x => x.RecievingFacilityID,
                        principalTable: "Facility",
                        principalColumn: "FacilityID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_VaccineExchange_Facility_SendingFacilityID",
                        column: x => x.SendingFacilityID,
                        principalTable: "Facility",
                        principalColumn: "FacilityID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_VaccineExchange_Vaccine_VaccineID",
                        column: x => x.VaccineID,
                        principalTable: "Vaccine",
                        principalColumn: "VaccineID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_VaccineExchange_RecievingFacilityID",
                table: "VaccineExchange",
                column: "RecievingFacilityID");

            migrationBuilder.CreateIndex(
                name: "IX_VaccineExchange_SendingFacilityID",
                table: "VaccineExchange",
                column: "SendingFacilityID");

            migrationBuilder.CreateIndex(
                name: "IX_VaccineExchange_VaccineID",
                table: "VaccineExchange",
                column: "VaccineID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "VaccineExchange");
        }
    }
}
