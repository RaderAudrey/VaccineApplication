﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RaderMVCWebProject.Data.Migrations
{
    public partial class AddedFacilityInventory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FacilityInventory",
                columns: table => new
                {
                    FacilityInventoryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CurrentInventory = table.Column<int>(type: "int", nullable: false),
                    FacilityID = table.Column<int>(type: "int", nullable: false),
                    VaccineID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FacilityInventory", x => x.FacilityInventoryID);
                    table.ForeignKey(
                        name: "FK_FacilityInventory_Facility_FacilityID",
                        column: x => x.FacilityID,
                        principalTable: "Facility",
                        principalColumn: "FacilityID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_FacilityInventory_Vaccine_VaccineID",
                        column: x => x.VaccineID,
                        principalTable: "Vaccine",
                        principalColumn: "VaccineID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FacilityInventory_FacilityID",
                table: "FacilityInventory",
                column: "FacilityID");

            migrationBuilder.CreateIndex(
                name: "IX_FacilityInventory_VaccineID",
                table: "FacilityInventory",
                column: "VaccineID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FacilityInventory");
        }
    }
}
