﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RaderMVCWebProject.Data.Migrations
{
    public partial class addedFacilityAdmintoVaxShipment : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "FacilityAdminID",
                table: "VaxShipment",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_VaxShipment_FacilityAdminID",
                table: "VaxShipment",
                column: "FacilityAdminID");

            migrationBuilder.AddForeignKey(
                name: "FK_VaxShipment_AspNetUsers_FacilityAdminID",
                table: "VaxShipment",
                column: "FacilityAdminID",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_VaxShipment_AspNetUsers_FacilityAdminID",
                table: "VaxShipment");

            migrationBuilder.DropIndex(
                name: "IX_VaxShipment_FacilityAdminID",
                table: "VaxShipment");

            migrationBuilder.DropColumn(
                name: "FacilityAdminID",
                table: "VaxShipment");
        }
    }
}
