﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using RaderMVCWebProject.Models;
using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RaderMVCWebProject.Data
{
    public class DbInitializer
    {
        public static void Initialize(IServiceProvider services)
        {
            //1.database service
            ApplicationDbContext database = services.GetRequiredService<ApplicationDbContext>();

            //2.roles
            RoleManager<IdentityRole> rolemanager = services.GetRequiredService<RoleManager<IdentityRole>>();

            //3.users
            UserManager<ApplicationUser> usermanager = services.GetRequiredService<UserManager<ApplicationUser>>();


            string hubManagerRole = "HubManager";
            string facilityAdminRole = "FacilityAdmin";
            string patientRole = "Patient";
            string sysAdminRole = "SysAdmin";

            if (!database.Roles.Any())
            {
                IdentityRole role = new IdentityRole(hubManagerRole);
                rolemanager.CreateAsync(role).Wait();

                role = new IdentityRole(facilityAdminRole);
                rolemanager.CreateAsync(role).Wait();

                role = new IdentityRole(patientRole);
                rolemanager.CreateAsync(role).Wait();

                role = new IdentityRole(sysAdminRole);
                rolemanager.CreateAsync(role).Wait();
            }


            if (!database.ApplicationUser.Any())
            {
                DateTime dateOfBirth = new DateTime(2000, 10, 1);

                Patient patient = new Patient("Test", "Patient1", "Test.Patient1@test.com", "3040000001", "Test.Patient1", "109 Wilson Ave, Morgantown, WV 26501", dateOfBirth, 3);
                patient.EmailConfirmed = true;
                usermanager.CreateAsync(patient).Wait();
                usermanager.AddToRoleAsync(patient, patientRole).Wait();

                patient = new Patient("Test", "Patient2", "Test.Patient2@test.com", "3040000001", "Test.Patient2", "109 Wilson Ave, Morgantown, WV 26501", dateOfBirth, 3);
                patient.EmailConfirmed = true;
                usermanager.CreateAsync(patient).Wait();
                usermanager.AddToRoleAsync(patient, patientRole).Wait();

                ApplicationUser applicationUser = new ApplicationUser("Test", "SysAdmin", "Test.SysAdmin@test.com", "3040000002", "Test.SysAdmin");
                applicationUser.EmailConfirmed = true;
                usermanager.CreateAsync(applicationUser).Wait();
                usermanager.AddToRoleAsync(applicationUser, sysAdminRole).Wait();

                FacilityAdmin facilityadmin = new FacilityAdmin("Test", "HospitalFacilityAdmin", "Test.HospitalFacilityAdmin@test.com", "3040000003", "Test.HospitalFacilityAdmin");
                facilityadmin.EmailConfirmed = true;
                usermanager.CreateAsync(facilityadmin).Wait();
                usermanager.AddToRoleAsync(facilityadmin, facilityAdminRole).Wait();

                facilityadmin = new FacilityAdmin("Test", "PharmacyFacilityAdmin", "Test.PharmacyFacilityAdmin@test.com", "3040000003", "Test.PharmacyFacilityAdmin");
                facilityadmin.EmailConfirmed = true;
                usermanager.CreateAsync(facilityadmin).Wait();
                usermanager.AddToRoleAsync(facilityadmin, facilityAdminRole).Wait();

                facilityadmin = new FacilityAdmin("Test", "NursingHomeFacilityAdmin", "Test.NursingHomeFacilityAdmin@test.com", "3040000003", "Test.NursingHomeFacilityAdmin");
                facilityadmin.EmailConfirmed = true;
                usermanager.CreateAsync(facilityadmin).Wait();
                usermanager.AddToRoleAsync(facilityadmin, facilityAdminRole).Wait();
            }



            //populate the database

            if (!database.Vaccine.Any())//will come back as false when there is no data to begin with
            {
                Vaccine vaccine = new Vaccine("Pfizer", 3, 2);
                database.Vaccine.Add(vaccine);
                database.SaveChanges();

                vaccine = new Vaccine("Moderna", 4, 2);
                database.Vaccine.Add(vaccine);
                database.SaveChanges();

                vaccine = new Vaccine("Johnson & Johnson", 0, 1);
                database.Vaccine.Add(vaccine);
                database.SaveChanges();
            }

            if (!database.Facility.Any())
            {
                Facility facility = new Facility("WVU Hospital", "1 Medical Center Dr, Morgantown, WV 26506");
                database.Facility.Add(facility);
                database.SaveChanges();

                FacilityAdmin facilityadminforfacility = database.FacilityAdmin.Where(fa => fa.Email == "Test.HospitalFacilityAdmin@test.com").FirstOrDefault();

                facility.FacilityAdminID = facilityadminforfacility.Id;
                database.Facility.Update(facility);
                database.SaveChanges();

                facilityadminforfacility.FacilityID = 1;


                facility = new Facility("Walgreens", "897 Chestnut Ridge Rd, Morgantown, WV 26505");
                database.Facility.Add(facility);
                database.SaveChanges();

                facilityadminforfacility = database.FacilityAdmin.Where(fa => fa.Email == "Test.PharmacyFacilityAdmin@test.com").FirstOrDefault();

                facility.FacilityAdminID = facilityadminforfacility.Id;
                database.Facility.Update(facility);
                database.SaveChanges();

                facilityadminforfacility.FacilityID = 2;

                facility = new Facility("Sundale Nursing Home", "800 J D Anderson Dr, Morgantown, WV 26505");
                database.Facility.Add(facility);
                database.SaveChanges();

                facilityadminforfacility = database.FacilityAdmin.Where(fa => fa.Email == "Test.NursingHomeFacilityAdmin@test.com").FirstOrDefault();

                facility.FacilityAdminID = facilityadminforfacility.Id;
                database.Facility.Update(facility);
                database.SaveChanges();

                facilityadminforfacility.FacilityID = 3;
            }


            if(!database.VaxShipment.Any())
            {
                List<VaxShipment> vaccineShipmentList = new List<VaxShipment>();
                DateTime startdate = new DateTime(2021, 4, 4);

                VaxShipment vaccineShipment = new VaxShipment(1, 1, startdate, 15);
                vaccineShipmentList.Add(vaccineShipment);
                
                vaccineShipment = new VaxShipment(1, 2, startdate, 25);
                vaccineShipmentList.Add(vaccineShipment);

                vaccineShipment = new VaxShipment(1, 3, startdate, 35);
                vaccineShipmentList.Add(vaccineShipment);

                startdate = new DateTime(2021, 4, 11);

                vaccineShipment = new VaxShipment(2, 1, startdate, 101);
                vaccineShipmentList.Add(vaccineShipment);

                DateTime endDate = new DateTime(2021, 4, 15);

                vaccineShipment = new VaxShipment(2, 2, startdate, 151, endDate);
                vaccineShipmentList.Add(vaccineShipment);

                vaccineShipment = new VaxShipment(2, 3, startdate, 201, endDate);
                vaccineShipmentList.Add(vaccineShipment);


                database.VaxShipment.AddRange(vaccineShipmentList);
                database.SaveChanges();
            }

            if (!database.FacilityInventory.Any())
            {
                //Facility #1
                FacilityInventory facilityInventory = new FacilityInventory(1, 1);
                //stating with inventory
                facilityInventory.CurrentInventory = 10;
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();

                facilityInventory = new FacilityInventory(1, 2);
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();

                facilityInventory = new FacilityInventory(1, 3);
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();

                //Facility #2
                facilityInventory = new FacilityInventory(2, 1);
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();

                facilityInventory = new FacilityInventory(2, 2);
                //stating with inventory
                facilityInventory.CurrentInventory = 10;
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();

                facilityInventory = new FacilityInventory(2, 3);
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();

                //Facility #3
                facilityInventory = new FacilityInventory(3, 1);
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();

                facilityInventory = new FacilityInventory(3, 2);
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();

                facilityInventory = new FacilityInventory(3, 3);
                //starrting with inventory
                facilityInventory.CurrentInventory = 10;
                database.FacilityInventory.Add(facilityInventory);
                database.SaveChanges();
            }

            if (!database.AppointmentAvailability.Any())
            {
                DateTime apptstart = new DateTime(2021, 12, 31, 14, 00, 00);

                AppointmentAvailability appointmentAvailability = new AppointmentAvailability(1, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();

                appointmentAvailability = new AppointmentAvailability(2, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();

                appointmentAvailability = new AppointmentAvailability(3, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();

                appointmentAvailability = new AppointmentAvailability(4, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();

                apptstart = new DateTime(2021, 12, 10, 12, 00, 00);

                appointmentAvailability = new AppointmentAvailability(5, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();

                appointmentAvailability = new AppointmentAvailability(6, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();

                appointmentAvailability = new AppointmentAvailability(7, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();

                apptstart = new DateTime(2021, 12, 11, 11, 00, 00);

                appointmentAvailability = new AppointmentAvailability(8, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();

                appointmentAvailability = new AppointmentAvailability(9, apptstart);
                database.AppointmentAvailability.Add(appointmentAvailability);
                database.SaveChanges();
            }


            if (!database.AppointmentAvailabilityAlternate.Any())
            {
                DateTime availabilityDateTime = DateTime.Now.AddDays(7);

                AppointmentAvailabilityAlternate appointmentAvailabilityAlternate = new AppointmentAvailabilityAlternate(availabilityDateTime);
                database.AppointmentAvailabilityAlternate.Add(appointmentAvailabilityAlternate);
                database.SaveChanges();

                availabilityDateTime = availabilityDateTime.AddMinutes(30);

                appointmentAvailabilityAlternate = new AppointmentAvailabilityAlternate(availabilityDateTime);
                database.AppointmentAvailabilityAlternate.Add(appointmentAvailabilityAlternate);
                database.SaveChanges();

                availabilityDateTime = availabilityDateTime.AddMinutes(30);

                appointmentAvailabilityAlternate = new AppointmentAvailabilityAlternate(availabilityDateTime);
                database.AppointmentAvailabilityAlternate.Add(appointmentAvailabilityAlternate);
                database.SaveChanges();

                availabilityDateTime = availabilityDateTime.AddDays(7);

                appointmentAvailabilityAlternate = new AppointmentAvailabilityAlternate(availabilityDateTime);
                database.AppointmentAvailabilityAlternate.Add(appointmentAvailabilityAlternate);
                database.SaveChanges();

                availabilityDateTime = availabilityDateTime.AddMinutes(30);

                appointmentAvailabilityAlternate = new AppointmentAvailabilityAlternate(availabilityDateTime);
                database.AppointmentAvailabilityAlternate.Add(appointmentAvailabilityAlternate);
                database.SaveChanges();

                availabilityDateTime = availabilityDateTime.AddMinutes(30);

                appointmentAvailabilityAlternate = new AppointmentAvailabilityAlternate(availabilityDateTime);
                database.AppointmentAvailabilityAlternate.Add(appointmentAvailabilityAlternate);
                database.SaveChanges();
            }




        }//end initialize method

    }//end class

}//end namespace
