﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RaderClassLibrary;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaderMVCWebProject.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {                  
        public DbSet<FacilityAdmin> FacilityAdmin { get; set; }
        public DbSet<ApplicationUser> ApplicationUser { get; set; }
        public DbSet<Facility> Facility { get; set; }
        public DbSet<Patient> Patient { get; set; }
        public DbSet<Vaccine> Vaccine { get; set; }
        public DbSet<VaxShipment> VaxShipment { get; set; }
        public DbSet<VaccineExchange> VaccineExchange { get; set; }
        public DbSet<FacilityInventory> FacilityInventory { get; set;  }
        public DbSet<AppointmentAvailability> AppointmentAvailability { get; set; }
        public DbSet<AppointmentAvailabilityAlternate> AppointmentAvailabilityAlternate { get; set; }
        public DbSet<MultipleAppointmentScheduler> MultipleAppointmentScheduler { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }//end constructor

    }//end class
}//end namespace
